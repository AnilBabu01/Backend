module.exports.UserCollection = require('./User.Collaction');
module.exports.AuthCollection = require('./Auth.Collaction');
module.exports.DonationCollection = require('./Donation.Collaction');
module.exports.ItrCollection = require('./Itr.Collaction');
module.exports.VoucherCollection = require('./Voucher.Collection');
module.exports.Room = require('./Room.collection');